ASSETS --

These files should be extracted at the root world directory.
E.g if my world is named "Classic", I would extract them to Worlds/Classic/